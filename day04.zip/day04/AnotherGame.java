package day04;

public class AnotherGame {

	public static void main(String[] args) {
		System.out.println(">>> 여러 게임 있음 <<<<");
		//MyGame.main(args);//[x]
		MyGame.startGame();//[o]

	}

}
